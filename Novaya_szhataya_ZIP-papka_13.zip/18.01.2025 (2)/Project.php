<?php

class Project {
    public $name;
    private $tasks = [];

    public function __construct($name) {
        $this->name = $name;
    }

    public function __destruct() {
        echo "Проект '{$this->name}' завершен.\n";
    }

    public function addTask($task) {
        $this->tasks[] = $task;
        echo "Задача '{$task->title}' добавлена в '{$this->name}'.\n";
    }

    public function __toString() {
        return "Проект: {$this->name}, Задач: " . count($this->tasks) . "\n";
    }
}