<?php

class Task {
    public $title, $description, $status = "Не выполнено";

    public function __construct($title, $description) {
        $this->title = $title;
        $this->description = $description;
    }

    public function __destruct() {
        echo "Задача '{$this->title}' удалена.\n";
    }

    public function __call($method, $args) {
        if (strpos($method, 'set') === 0) {
            $prop = strtolower(substr($method, 3));
            $this->$prop = $args[0];
            echo "{$prop} изменен на '{$args[0]}'.\n";
        } elseif (strpos($method, 'get') === 0) {
            $prop = strtolower(substr($method, 3));
            return $this->$prop;
        }
    }

    public function __toString() {
        return "Задача: {$this->title} — {$this->status}\n";
    }
}