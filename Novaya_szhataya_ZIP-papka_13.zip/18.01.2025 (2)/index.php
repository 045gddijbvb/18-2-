<?php

include 'Task.php';
include 'Project.php';

$project = new Project("Новый проект");
$task1 = new Task("Сделать API", "Разработать API для системы");
$task2 = new Task("Написать тесты", "Покрыть код тестами");

$project->addTask($task1);
$project->addTask($task2);

$task1->setStatus("В процессе");
echo $task1->getStatus() . "\n";

echo $project;
echo $task1;
echo $task2;